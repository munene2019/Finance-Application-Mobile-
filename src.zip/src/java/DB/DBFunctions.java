/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rmunene
 */
public class DBFunctions {

    public Map<String, String> fundsTransfer(String phonumber, String recepientNo, int amount) {
        int availableAmount = 0;
        PreparedStatement ps;
        ResultSet rs;
        Map<String, String> requestMap = new HashMap<>();

        String sqlcheck = "SELECT * FROM tbaccounts  WHERE PhoneNumber='" + recepientNo + "'";
        try {
            ps = DBconnection.Connect().prepareStatement(sqlcheck);
            rs = ps.executeQuery();

            if (rs.next()) {
            } else {
                requestMap.put("status", "0");
                requestMap.put("message", "Account does not exist");
                return requestMap;
            }
        } catch (SQLException ex) {
            System.out.println("DB ERROR" + ex);
        }

        String sql = "SELECT * FROM tbaccounts  WHERE PhoneNumber='" + phonumber + "'and AvailableBal >= '" + amount + "'";

        try {
            ps = DBconnection.Connect().prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {

                availableAmount = Integer.parseInt(rs.getString("AvailableBal"));

                String sqlCredit = "update    tbaccounts set AvailableBal='" + amount + "',ActualBal='" + amount + "' WHERE PhoneNumber='" + recepientNo + "' ";

                ps = DBconnection.Connect().prepareStatement(sqlCredit);

                ps.execute();

                int debitAmount = availableAmount - amount;
                String sqlDebit = "update    tbaccounts set AvailableBal='" + debitAmount + "',ActualBal='" + amount + "'  WHERE PhoneNumber='" + phonumber + "' ";

                ps = DBconnection.Connect().prepareStatement(sqlDebit);
                ps.execute();
                requestMap.put("status", "1");
                requestMap.put("message", "Funds Transfer Succesful");

            } else {
                requestMap.put("status", "0");
                requestMap.put("message", "Insufficient Funds");
            }
        } catch (SQLException ex) {
            System.out.println("DB EXCEPTION  " + ex);
        }
        return requestMap;
    }

    public Map<String, String> balanceInquiry(String phonumber) {
        PreparedStatement ps;
        ResultSet rs;
        Map<String, String> requestMap = new HashMap<>();
        String sql = "SELECT * FROM tbaccounts  WHERE PhoneNumber='" + phonumber + "' ";
        try {
            ps = DBconnection.Connect().prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                requestMap.put("Request", "Balance Inquiry");
                requestMap.put("AvailableBal", rs.getString("AvailableBal"));
                requestMap.put("ActualBal", rs.getString("ActualBal"));
                requestMap.put("status", "1");

            } else {
                requestMap.put("status", "0");
            }
        } catch (SQLException ex) {
            System.out.println("DB EXCEPTION  " + ex);
        }
        return requestMap;
    }

    public Map<String, String> customerRegistration(int nationalID, String firstName, String lastName, String phonenumber, String uuid) {
        Connection connection = DBconnection.Connect();
        PreparedStatement ps;
        ResultSet rs;
        Map<String, String> requestMap = new HashMap<>();
        int pin = 12345;
        boolean results = false;
        int avail = 0;
        int actual = 0;

        String sqlcheck = "SELECT * FROM tbcustomers  WHERE PhoneNumber='" + phonenumber + "'";
        try {
            ps = DBconnection.Connect().prepareStatement(sqlcheck);
            rs = ps.executeQuery();

            if (rs.next()) {
                requestMap.put("status", "0");
                requestMap.put("message", "Customer Already Exist");
                return requestMap;
            } else {

            }
        } catch (SQLException ex) {
            System.out.println("DB ERROR" + ex);
        }
        String sql2 = "Insert into tbaccounts(`NationalID`, `AvailableBal`, `ActualBal`,`PhoneNumber`)values('" + nationalID + "','" + actual + "','" + avail + "','" + phonenumber + "')";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.execute();
        } catch (SQLException ex) {
            System.out.println("db error" + ex);
        }

        String sql = "Insert into tbcustomers(`NationalID`, `FirstName`, `LastName`,`PhoneNumber`,`Uuid`,`PIN`)values('" + nationalID + "','" + firstName + "','" + lastName + "','" + phonenumber + "','" + uuid + "','" + pin + "')";

        try {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            results = preparedStatement.execute();
        } catch (SQLException ex) {
            System.out.println("db error" + ex);
        }
        requestMap.put("status", "1");
        requestMap.put("message", "Registration Successful");
        return requestMap;
    }

    public Map<String, String> Login(String phoneNumber, String pin) {
        PreparedStatement ps;
        ResultSet rs;
        Map<String, String> requestMap = new HashMap<>();

        String sqlcheck = "SELECT * FROM tbcustomers  WHERE PhoneNumber='" + phoneNumber + "'";
        try {
            ps = DBconnection.Connect().prepareStatement(sqlcheck);
            rs = ps.executeQuery();

            if (rs.next()) {

            } else {
                requestMap.put("status", "0");
                requestMap.put("message", "Customer Does Not  Exist.Kindly Register");
                return requestMap;
            }
        } catch (SQLException ex) {
            System.out.println("DB ERROR" + ex);
        }
        String sql = "SELECT * FROM tbcustomers  WHERE PhoneNumber='" + phoneNumber + "' AND PIN='" + pin + "' ";

        try {
            ps = DBconnection.Connect().prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                requestMap.put("status", "1");
                requestMap.put("message", "login succesful");
            } else {
                requestMap.put("status", "0");
                requestMap.put("message", "Wrong Credentials");
            }
        } catch (SQLException ex) {
            System.out.println("DB EXCEPTION  " + ex);
        }
        return requestMap;
    }

}
